#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float r;
	cout << "Nhap ban kinh = ";
	cin >> r;
	float p = r * 3.14 * 2;
	cout << "Chu vi duong tron la = ";
	cout << p;
	return 1;
}