#include<iostream>
using namespace std;
int main()
{
	int x, n;
	cout << "Nhap x = ";
	cin >> x;
	cout << "Nhap n = ";
	cin >> n;
	float s = 0;
	float t = 1;
	int m = 1;
	int i = 1;
	while (i <= n)
	{
		m = m * i;
		t = t * x;
		s = s + t / m;
		i = i + 1;
	}
	cout << "Tong la = " << s;
	return 1;
}