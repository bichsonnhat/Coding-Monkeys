#include<iostream>
using namespace std;
int main()
{
	float r;
	cout << "Nhap ban kinh r = ";
	cin >> r;
	float s = r * r * 3.14 * 4;
	cout << "Dien tich hinh cau la = ";
	cout << s;
	return 0;
}