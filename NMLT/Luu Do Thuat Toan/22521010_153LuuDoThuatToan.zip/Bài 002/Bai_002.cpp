#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float r;
	cout << "Nhap ban kinh = ";
	cin >> r;
	float dt = 3.14 * r * r;
	cout << "Dien tich duong tron la = ";
	cin >> dt;
	return 0;
}