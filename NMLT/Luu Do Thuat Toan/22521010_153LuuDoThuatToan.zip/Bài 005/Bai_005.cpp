#include<iostream>
using namespace std;
int main()
{
	float r;
	cout << "Nhap ban kinh r = ";
	cin >> r;
	float v = (4 * 3.14 * r * r * r) / 3;
	cout << "The tich hinh cau la = ";
	cout << v;
	return 0;
}