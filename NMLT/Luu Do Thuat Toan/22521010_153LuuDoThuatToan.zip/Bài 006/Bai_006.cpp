#include<iostream>
using namespace std;
int main()
{
	float c;
	cout << "Nhap do C = ";
	cin >> c;
	float f = (9 * c) / 5 + 32;
	cout << "Do F la = ";
	cout << f;
	return 0;
}